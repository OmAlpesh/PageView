//
//  PageMenuFramework.h
//  PageMenuFramework
//
//  Created by Rui Peres on 17/09/2015.
//  Copyright © 2015 PageMenu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PageMenuFramework.
FOUNDATION_EXPORT double PageMenuFrameworkVersionNumber;

//! Project version string for PageMenuFramework.
FOUNDATION_EXPORT const unsigned char PageMenuFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PageMenuFramework/PublicHeader.h>


